// 引入这个变量后 vite 会自动注入 hot
import.meta.hot
import "./icon.png"
console.log(222,import.meta.url);

export const run = 222
