"use strict";
var _documentCurrentScript = typeof document !== "undefined" ? document.currentScript : null;
console.log(222, typeof document === "undefined" ? require("url").pathToFileURL(__filename).href : _documentCurrentScript && _documentCurrentScript.src || new URL("index.js", document.baseURI).href);
//# sourceMappingURL=index.js.map
