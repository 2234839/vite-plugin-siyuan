## 思源 vite 开发插件

可通过此插件连接 vite 启动的服务，自动加载和卸载插件

此项目由 https://github.com/2234839/OceanPress_siyuan_plugin 自动生成